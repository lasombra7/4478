using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Card : MonoBehaviour {
    public CardState cardState;
    public CardPatten cardPatten;
    public GameManager gameManager;
    void Start(){
        cardState = CardState.unflip;
        gameManager = GameObject.FindGameObjectWithTag("GameManager").GetComponent<GameManager>();
    }

    private void OnMouseUp(){    //actions when click on mouse
        if (cardState.Equals(CardState.flip)){    //same care can't use teo times
            return;
        }
        if (gameManager.ReadyToCompareCards){    //only can flip two cards
            return;
        }
        OpenCard();
        gameManager.AddCardInCardComparison(this);
        gameManager.CompareCardsInList();
    }

    void OpenCard(){    //card flip
        transform.eulerAngles = new Vector3(0, 180, 0);
        cardState = CardState.flip;
    }
}

public enum CardState{    //Create three situations
unflip, flip, succeed
}

public enum CardPatten{    //8 pairs
    none, bean, doraemon, minion, mouse, noddy, popeye, scooby, shinchan
}
