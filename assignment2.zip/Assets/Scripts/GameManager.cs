using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class GameManager : MonoBehaviour{

    [Header("pair list")]
    public List<Card> cardComparison;

    [Header("type list")]
    public List<CardPatten> cardsToBePutIn;

    public Transform[] positions;
    void Start(){
        GenerateRandomCards();
    }

    void SetupCardsToBePutIn(){    //turn Enum to List
        Array array = Enum.GetValues(typeof(CardPatten));
        foreach (var item in array){
            cardsToBePutIn.Add((CardPatten)item);
        }
        cardsToBePutIn.RemoveAt(0);    //delete none
    }

    void GenerateRandomCards(){    //randomly give cards
        int positionIndex = 0;    //start with 0
        for(int i =0; i < 2; i++){    //create 16 cards
            SetupCardsToBePutIn();    //prepare the card
            int maxRandomNumber = cardsToBePutIn.Count;    //max number is 8

            for (int j = 0; j < maxRandomNumber; maxRandomNumber--){
                int randomNumber = UnityEngine.Random.Range(0, maxRandomNumber);    //pick up a number, the smallest number is 0, biggist number is 7
                AddNewCard(cardsToBePutIn[randomNumber],positionIndex);
                cardsToBePutIn.RemoveAt(randomNumber);
                    positionIndex++;
            }
        }
    }

    void AddNewCard(CardPatten cardPatten,int positionIndex){    //generate a card at random
        GameObject card = Instantiate(Resources.Load<GameObject>("Prefabs/Card"));
        card.GetComponent<Card>().cardPatten = cardPatten;
        card.name = "Card_" + cardPatten.ToString();
        card.transform.position = positions[positionIndex].position;    //get position

        GameObject graphic = Instantiate(Resources.Load<GameObject>("prefabs/pic"));
        graphic.GetComponent<SpriteRenderer>().sprite = Resources.Load<Sprite>("Graphics/"+cardPatten.ToString());
        graphic.transform.SetParent(card.transform);
        graphic.transform.localPosition = new Vector3(0, 2.72f, 0.1f);    //set up lacation
        graphic.transform.eulerAngles = new Vector3(0, 180, 0);
    }
    public void AddCardInCardComparison(Card card){    //to check if the card match
        cardComparison.Add(card);
    }

    public bool ReadyToCompareCards{
        get{
            if (cardComparison.Count == 2){
                return true;
            }

            else{
                return false;
            }

        }
    }

    public void CompareCardsInList(){
        if(ReadyToCompareCards){    //to show it paired successfully.
            //Debug.Log("Could pair the cards");
            if (cardComparison[0].cardPatten == cardComparison[1].cardPatten){
                Debug.Log("two same card");
                foreach(var card in cardComparison){
                    card.cardState = CardState.succeed;
                }
                ClearCardComparison();
            }

            else{
                Debug.Log("it is not same");
                StartCoroutine( MissMatchCards());    //include turn and clear
            }
        }
    }

    void ClearCardComparison(){    //clear the card if it compare
        cardComparison.Clear();
    }

    void TurnBackCards(){
        foreach(var card in cardComparison){
            card.gameObject.transform.eulerAngles = Vector3.zero;    //if not match then flip the card to vector (0,0,0)
            card.cardState = CardState.unflip;
        }
    }

    IEnumerator MissMatchCards(){    //if doesn't match, shows the wrong card 1.5 seconds
        yield return new WaitForSeconds(1);
        TurnBackCards();
        ClearCardComparison();
    }
}
